class FilterLink:
    pass
